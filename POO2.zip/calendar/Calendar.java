/**
 * @author Dinis Raleiras 67819
 * @author Filipe Nobre 67850
 */
package calendar;

import exceptions.*;
import events.*;
import users.*;



import java.time.LocalDateTime;
import java.util.Iterator;
public interface Calendar {
    /**
     * Creates a new user account with the specified name and role.
     *
     * @param name the name of the user.
     * @param role the role of the user.
     * @throws AlreadyRegisteredException if a user with the same name already exists.
     * @throws RoleException if the specified role is not valid.
     * @pre:  name!=null && role!=null
     */
    void createAccount(String name, String role) throws AlreadyRegisteredException, RoleException;
    /**
     * Creates a new Manager user with the specified name.
     *
     * @param name the name of the Manager user.
     * @return a new Manager user object.
     * @pre: name!=null
     */
    User createManager(String name);
    /**
     * Creates a new Staff user with the specified name.
     *
     * @param name the name of the Staff user.
     * @return a new Staff user object.
     * @pre: name!=null
     */
    User createStaff(String name);
    /**
     * Creates a new Guest user with the specified name.
     *
     * @param name the name of the Guest user.
     * @return a new Guest user object.
     * @pre: name!=null
     */
    User createGuest(String name);
    /**
     * Checks if the user with the specified name is a Staff user.
     *
     * @param name the name of the user to check.
     * @return true if the user is a Staff user, false otherwise.
     * @throws NoAccException if no user account with the specified name exists.
     * @pre: name!=null
     */
    boolean isStaff(String name) throws NoAccException;
    /**
     * Checks if a user account with the specified name exists.
     *
     * @param name the name of the user to check.
     * @return true if a user account with the specified name exists, false otherwise.
     * @pre: name!=null
     */
    boolean userExist(String name);
    /**
     * Retrieves an iterator over all user accounts.
     *
     * @return an iterator over all user accounts.
     */
    Iterator<User> getAccounts();
    /**
     * Checks if there are no user accounts registered.
     *
     * @return true if there are no user accounts registered, false otherwise.
     */
    boolean noAccountsRegistered();
    /**
     * Creates a new event with the specified details.
     *
     * @param name the name of the event promoter.
     * @param eName the name of the event to be created.
     * @param priority the priority of the event.
     * @param date the date of the event.
     * @param topics the topics to be covered in the event.
     * @throws NoAccException if the specified user account does not exist.
     * @throws UnknownPriorityException if the specified priority is unknown.
     * @throws GuestAccountException if the user account is a guest account and cannot create events.
     * @throws StaffException if the user account is a staff account and cannot create events.
     * @throws EventAlreadyExistsException if an event with the same name already exists.
     * @throws SameDateException if another event is scheduled on the same date.
     * @pre: name !=null && eName!=null && priority !=null && date!=null && topics!=null
     */
    void createEvent(String name, String eName, String priority, LocalDateTime date, String topics) throws NoAccException,
            UnknownPriorityException, GuestAccountException, StaffException, EventAlreadyExistsException, SameDateException;
    /**
     * Creates a new mid-priority event with the specified details.
     *
     * @param name the name of the event promoter.
     * @param eName the name of the event to be created.
     * @param date the date of the event.
     * @param topics the topics to be covered in the event.
     * @return the created mid-priority event.
     * @throws GuestAccountException if the user account is a guest account and cannot create events.
     * @throws EventAlreadyExistsException if an event with the same name already exists.
     * @throws SameDateException if another event is scheduled on the same date.
     * @pre: name !=null && eName!=null && priority !=null && date!=null && topics!=null
     */
    Event createMidPriorityEvent(String name, String eName, LocalDateTime date, String topics) throws GuestAccountException,
            EventAlreadyExistsException, SameDateException;
    /**
     * Creates a new high-priority event with the specified details.
     *
     * @param name the name of the event promoter.
     * @param eName the name of the event to be created.
     * @param date the date of the event.
     * @param topics the topics to be covered in the event.
     * @return the created high-priority event.
     * @throws GuestAccountException if the user account is a guest account and cannot create events.
     * @throws StaffException if the user account is a staff account and cannot create high-priority events.
     * @throws EventAlreadyExistsException if an event with the same name already exists.
     * @throws SameDateException if another event is scheduled on the same date.
     * @pre: name !=null && eName!=null && priority !=null && date!=null && topics!=null
     */
    Event createHighPriorityEvent(String name, String eName, LocalDateTime date, String topics) throws GuestAccountException,
            StaffException, EventAlreadyExistsException, SameDateException;
    /**
     * Checks if the user associated with the provided name has no events scheduled.
     *
     * @param name the name of the user to check.
     * @return true if the user has no events scheduled, false otherwise.
     * @throws NoAccException if the provided user account does not exist.
     * @pre: name!=null
     */
    boolean HaveNoEvents(String name)throws NoAccException;
    /**
     * Retrieves an iterator over the events associated with the user specified by the provided name.
     *
     * @param name the name of the user whose events are to be listed.
     * @return an iterator over the events associated with the specified user.
     * @throws NoAccException if the provided user account does not exist.
     * @pre: name!=null
     */
    Iterator<Event> listAccountEvents(String name);
    /**
     * Retrieves information about the specified event associated with the user specified by the provided name.
     *
     * @param name the name of the user whose event information is to be retrieved.
     * @param eName the name of the event for which information is to be retrieved.
     * @return the event object containing information about the specified event.
     * @throws NoAccException if the provided user account does not exist.
     * @throws NoEventException if the specified event does not exist.
     * @pre: name!= null && eName!=null
     */
    Event getEventInfo(String name, String eName) throws NoAccException, NoEventException;
    /**
     * Checks if the specified event associated with the user specified by the provided name is of high priority.
     *
     * @param name the name of the user associated with the event.
     * @param eName the name of the event to check for high priority.
     * @return true if the event is of high priority, false otherwise.
     * @throws NoAccException if the provided user account does not exist.
     * @throws NoEventException if the specified event does not exist.
     * @pre: name!=null && eName!=null
     */
    boolean isHigh(String name, String eName) throws NoAccException, NoEventException;
    /**
     * Invites a manager or guest user to the specified event.
     *
     * @param iName the name of the user to invite.
     * @param name the name of the user associated with the event.
     * @param eName the name of the event to which the user is invited.
     * @throws NoAccException if the specified user account or event does not exist.
     * @throws AlreadyInvitedException if the user is already invited to the event.
     * @throws SameDateException if the user is invited to another event on the same date.
     * @throws NoEventException if the specified event does not exist.
     * @pre: name !=null && eName!=null && iName!=null
     */
    void inviteAManagerOrGuest(String iName, String name, String eName) throws NoAccException, AlreadyInvitedException,
            SameDateException, NoEventException;
    /**
     * Removes the specified event from the calendar.
     * Removes the event from the list of accepted events for all users who have accepted it.
     * Removes the event invitation from the list of invited events for all users who were invited.
     *
     * @param event the event to be removed.
     * @pre: event !=null && !NoEventException()
     */
    void removeEvent(Event event);
    /**
     * Invites a staff member to an event, handling conflicts if they already have events scheduled on the same date.
     * If the staff member is already invited to the event, an AlreadyInvitedException is thrown.
     * If the staff member has an event scheduled on the same date and it's a high priority event, a SameDateException is thrown.
     * If the staff member has an event scheduled on the same date and it's a mid priority event, it's removed from the calendar,
     * and the staff member is added to the invited list of the new event.
     * The method returns an iterator over the events that were removed due to conflicts.
     *
     * @param iName the name of the staff member to be invited.
     * @param name the name of the event promoter.
     * @param eName the name of the event.
     * @return an iterator over the events that were removed due to conflicts.
     * @throws AlreadyInvitedException if the staff member is already invited to the event.
     * @throws SameDateException if the staff member has a high priority event scheduled on the same date.
     * @pre: name !=null && eName!=null && iName!=null
     *
     */
    Iterator<Event> inviteAStaff(String iName, String name, String eName) throws AlreadyInvitedException, SameDateException;
    /**
     * Checks if the specified user is the promoter of the given event.
     *
     * @param event the event to check.
     * @param iName the name of the user to check.
     * @return true if the specified user is the promoter of the event, false otherwise.
     * @pre: iName!=null && event!=null
     */
    boolean isPromoter(Event event, String iName);
    /**
     * Searches for events containing the specified topics and returns an iterator over the matching events.
     *
     * @param topics the topics to search for, separated by spaces.
     * @return an iterator over the events containing the specified topics, ordered by the number of matched topics in descending
     * order, then by event name, and finally by promoter name.
     * @pre: topics !=null
     */
    Iterator<Event> searchTopics(String topics);
    /**
     * Responds to an event invitation with the specified answer and returns an iterator over the events affected by the response.
     *
     * @param iName the name of the user responding to the invitation.
     * @param name the name of the event promoter.
     * @param eName the name of the event.
     * @param answer the response to the invitation (accept, reject, or no_answer).
     * @return an iterator over the events affected by the response (accepted or rejected events).
     * @throws NoAccException if either the responder or the event promoter does not exist in the system.
     * @throws InvalidAnswerException if the provided answer is not valid (accept, reject, or no_answer).
     * @throws NoEventException if the specified event does not exist.
     * @throws NotInvitedException if the responder is not invited to the event.
     * @throws AlreadyAnsweredException if the responder has already responded to the invitation.
     * @throws SameDateException if accepting the invitation would result in scheduling conflicts with other events.
     * @pre: name !=null && eName!=null && iName!=null && answer!=null
     */
    Iterator<Event> response(String iName, String name, String eName, String answer) throws NoAccException, InvalidAnswerException,
            NoEventException, NotInvitedException, AlreadyAnsweredException, SameDateException;
}
