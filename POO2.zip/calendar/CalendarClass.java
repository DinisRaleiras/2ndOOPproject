/**
 * @author Dinis Raleiras 67819
 * @author Filipe Nobre 67850
 */
package calendar;

import java.time.LocalDateTime;
import java.util.*;

import exceptions.StaffException;

import exceptions.*;
import events.*;
import users.*;
import dataStruck.*;
import enums.*;



public class CalendarClass implements Calendar{
    private SortedSet<User> accounts;
    private List<Event> events;

    public CalendarClass() {
        accounts = new TreeSet<>();
        events = new ArrayList<>();
    }

    @Override
    public boolean isStaff(String name) throws NoAccException{
        if(!accounts.contains(new GuestClass(name))) {
            throw new NoAccException();
        }
        User user = getAccount(name);
        return user instanceof Staff;
    }

    @Override
    public boolean userExist(String name) {
        return accounts.contains(new GuestClass(name));
    }
    /**
     * Retrieves the user account with the specified name.
     *
     * @param name the name of the user account to retrieve.
     * @return the user account with the specified name.
     */
    private User getAccount(String name) {
        User user = new GuestClass(name);

        ArrayList<User> list = new ArrayList<>(accounts);
        int pos = list.indexOf(user);

        return list.get(pos);
    }

    @Override
    public Iterator<User> getAccounts() {
        return accounts.iterator();
    }

    @Override
    public void createAccount(String name, String role) throws AlreadyRegisteredException, RoleException {
        if(userExist(name)) {
            throw new AlreadyRegisteredException();
        }else if(role.equals(Role.GUEST.getRole())){
            accounts.add(createGuest(name));
        }else if(role.equals(Role.MANAGER.getRole())){
            accounts.add(createManager(name));
        }else if(role.equals(Role.STAFF.getRole())){
            accounts.add(createStaff(name));
        }else{
            throw new RoleException();
        }

    }

    @Override
    public User createManager(String name) {
        return new ManagerClass(name);
    }

    @Override
    public User createStaff(String name) {
        return new StaffClass(name);
    }

    @Override
    public User createGuest(String name) {
        return new GuestClass(name);
    }

    @Override
    public boolean noAccountsRegistered() {
        return accounts.isEmpty();
    }

    @Override
    public void createEvent(String name, String eName, String priority, LocalDateTime date, String topics)
            throws NoAccException, UnknownPriorityException, GuestAccountException, StaffException,
            EventAlreadyExistsException, SameDateException {
        if(!userExist(name)) {
            throw new NoAccException();
        }else if(priority.equals(Priority.MID.getPriority())) {
            events.add(createMidPriorityEvent(name, eName, date, topics));
        }else if(priority.equals(Priority.HIGH.getPriority())) {
            events.add(createHighPriorityEvent(name, eName, date, topics));
        }else {
            throw new UnknownPriorityException();
        }

    }

    @Override
    public Event createMidPriorityEvent(String name, String eName, LocalDateTime date, String topics)
            throws GuestAccountException, EventAlreadyExistsException, SameDateException {
        User user = getAccount(name);
        if(user instanceof GuestClass) {
            throw new GuestAccountException();
        }else {
            Employee employee = (Employee)user;
            return employee.createMidPriorityEvent(eName, date, topics);
        }
    }

    @Override
    public Event createHighPriorityEvent(String name, String eName, LocalDateTime date, String topics)
            throws GuestAccountException, StaffException, EventAlreadyExistsException, SameDateException {
        User user = getAccount(name);
        if(user instanceof GuestClass) {
            throw new GuestAccountException();
        }else if(user instanceof Staff) {
            throw new StaffException();
        }else {
            Manager manager = (Manager)user;
            return manager.createHighPriorityEvent(eName, date, topics);
        }
    }

    @Override
    public boolean HaveNoEvents(String name) throws NoAccException {
        if(accounts.contains(new GuestClass(name))) {
            User user = getAccount(name);
            return user.HaveNoEvents();
        }else {
            throw new NoAccException();
        }

    }

    @Override
    public Iterator<Event> listAccountEvents(String name) {
        User user = getAccount(name);
        return user.getAccountEvents();
    }

    @Override
    public Event getEventInfo(String name, String eName) throws NoAccException, NoEventException {
        if(!accounts.contains(new GuestClass(name))) {
            throw new NoAccException();
        }else if(!events.contains(new EventClass(getAccount(name), eName, null, null, null))) {
            throw new NoEventException();
        }else {
            int pos = events.indexOf(new EventClass(getAccount(name), eName, null, null, null));
            return events.get(pos);
        }

    }

    @Override
    public boolean isHigh(String name, String eName) throws NoAccException, NoEventException {
        if(!accounts.contains(new GuestClass(name))){
            throw new NoAccException();
        }else if(!events.contains(new EventClass(getAccount(name), eName, null, null, null))) {
            throw new NoEventException();
        }else {
            Event event = getEventInfo(name, eName);
            return event.getPriority().equals(Priority.HIGH);
        }
    }

    @Override
    public void inviteAManagerOrGuest(String iName, String name, String eName)
            throws NoAccException, AlreadyInvitedException, SameDateException, NoEventException {
        if(!accounts.contains(new GuestClass(name))) {
            throw new NoAccException();
        }else if(!events.contains(new EventClass(getAccount(name), eName, null, null, null))) {
            throw new NoEventException();
        }
        User invited = getAccount(iName);
        int pos = events.indexOf(new EventClass(getAccount(name), eName, null, null, null));
        Event event = events.get(pos);

        if(event.isInvited(invited)) {
            throw new AlreadyInvitedException();
        }else if(invited.eventInSameDate(event.getDate())){
            throw new SameDateException();
        }else {
            User user = getAccount(name);
            user.invite(invited, event);
        }
    }

    @Override
    public void removeEvent(Event event) {
        if(events.contains(event)) {
            ArrayList<User> listOfUsers = new ArrayList<>(accounts);
            for(int i = 0; i < listOfUsers.size(); i++) {
                User user = listOfUsers.get(i);
                if(user.haveEvent(event)) {
                    user.removeEvent(event);
                    user.removeInvite(event);
                }
            }
            events.remove(event);
        }
    }

    @Override
    public Iterator<Event> inviteAStaff(String iName, String name, String eName) throws AlreadyInvitedException, SameDateException{
        ArrayList<Event> listEvents = new ArrayList<>();
        User invited = getAccount(iName);
        int pos = events.indexOf(new EventClass(getAccount(name), eName, null, null, null));
        Event event = events.get(pos);
        if(event.isInvited(invited)) {
            throw new AlreadyInvitedException();
        }else if(invited.eventInSameDate(event.getDate())){
            Event other = invited.getEvent(event.getDate());
            if(other.getPromoter().equals(invited)) {
                listEvents.add(other);
                removeEvent(other);
            }else if(other.getPriority().equals(Priority.HIGH)) {
                throw new SameDateException();
            }
        }
        Staff staff = (Staff)invited;
        if(listEvents.isEmpty()) {
            listEvents.addAll(staff.rejectAllEventsInDate(event.getDate()));
        }
        invited.accept(event);
        return listEvents.iterator();
    }

    @Override
    public boolean isPromoter(Event event, String iName) {
        User user = getAccount(iName);
        return event.getPromoter().equals(user);
    }

    @Override
    public Iterator<Event> searchTopics(String topics) {
        String[] topicsArray = topics.split(" ");
        Comparator<Pair<Event, Integer>> comparator = (e1, e2) -> {
            int intComparison = Integer.compare(e1.getSecond(), e2.getSecond());
            if (intComparison != 0) {
                return -intComparison;
            }
            int topicsComparison = e1.getFirst().getName().compareTo(e2.getFirst().getName());
            if (topicsComparison != 0) {
                return topicsComparison;
            }
            return e1.getFirst().getPromoter().compareTo((e2.getFirst().getPromoter()));
        };
        TreeSet<Pair<Event, Integer>> list = new TreeSet<>(comparator);
        for(int i = 0; i < events.size(); i++){
            Event event = events.get(i);
            int n = event.getSameTopics(topicsArray);
            if(n > 0){
                list.add(new Pair<>(event, n));
            }
        }
        List<Event> eventsTopics = new ArrayList<>();
        Iterator<Pair<Event, Integer>> it = list.iterator();
        while(it.hasNext()) {
            eventsTopics.add(it.next().getFirst());
        }
        return eventsTopics.iterator();
    }

    @Override
    public Iterator<Event> response(String iName, String name, String eName, String answer) throws NoAccException,
            InvalidAnswerException, NoEventException, NotInvitedException, AlreadyAnsweredException, SameDateException {
        if(!userExist(iName) || !userExist(name)) {
            throw new NoAccException();
        }else if(answer.equals(Answer.ACCEPTED.getAnswer())) {
            return acceptInvite(iName, name, eName);
        }else if(answer.equals(Answer.REJECTED.getAnswer())) {
            rejectInvite(iName, name, eName);
            List<Event> events = new ArrayList<>();
            return events.iterator();
        }else{
            throw new InvalidAnswerException();
        }

    }

    /**
     * Rejects an invitation to an event on behalf of a user.
     *
     * @param iName the name of the user rejecting the invitation.
     * @param name the name of the event promoter.
     * @param eName the name of the event.
     * @throws NoEventException if the specified event does not exist.
     * @throws NotInvitedException if the user rejecting the invitation is not invited to the event.
     * @throws AlreadyAnsweredException if the user has already answered the invitation.
     */
    private void rejectInvite(String iName, String name, String eName) throws NoEventException,
            NotInvitedException, AlreadyAnsweredException{
        if(!events.contains(new EventClass(getAccount(name), eName, null, null, null))) {
            throw new NoEventException();
        }
        User invited = getAccount(iName);
        Event event = events.get(events.indexOf(new EventClass(getAccount(name), eName, null, null, null)));
        if(!event.isInvited(invited)) {
            throw new NotInvitedException();
        }else if(event.alreadyAnswered(invited)) {
            throw new AlreadyAnsweredException();
        }else {
            invited.rejectEvent(event);
        }
    }
    /**
     * Accepts an invitation to an event on behalf of a user and rejects other events with the same date.
     *
     * @param iName the name of the user accepting the invitation.
     * @param name the name of the event promoter.
     * @param eName the name of the event.
     * @return an iterator over the events that were rejected due to having the same date as the accepted event.
     * @throws NoEventException if the specified event does not exist.
     * @throws NotInvitedException if the user accepting the invitation is not invited to the event.
     * @throws AlreadyAnsweredException if the user has already answered the invitation.
     * @throws SameDateException if another invited event has the same date as the accepted event.
     */
    private Iterator<Event> acceptInvite(String iName, String name, String eName) throws NoEventException,
            NotInvitedException, AlreadyAnsweredException, SameDateException{
        if(!events.contains(new EventClass(getAccount(name), eName, null, null, null))) {
            throw new NoEventException();
        }
        User invited = getAccount(iName);
        Event event = events.get(events.indexOf(new EventClass(getAccount(name), eName, null, null, null)));
        if(!event.isInvited(invited)) {
            throw new NotInvitedException();
        }else if(event.alreadyAnswered(invited)) {
            throw new AlreadyAnsweredException();
        }else {
            return invited.acceptInvite(event);
        }
    }



}
