package dataStruck;


/**
 * @author Dinis Raleiras 67819
 * @author Filipe Nobre 67850
 * The Pair class represents a simple key-value pair.
 * @param <K> the type of the key.
 * @param <V> the type of the value.
 */
public class Pair<K, V> {
    private final K first;
    private final V second;

    /**
     * Constructs a Pair object with the specified key and value.
     *
     * @param first the key of the pair.
     * @param second the value of the pair.
     * @pre: first !=null && second !=null
     */
    public Pair(K first, V second) {
        this.first = first;
        this.second = second;
    }

    /**
     * Retrieves the key of the pair.
     *
     * @return the key of the pair.
     */
    public K getFirst() {
        return first;
    }

    /**
     * Retrieves the value of the pair.
     *
     * @return the value of the pair.
     */
    public V getSecond() {
        return second;
    }
}
