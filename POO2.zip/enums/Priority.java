/**
 @author Dinis Raleiras 67819
 @author Filipe Nobre 67850
  * The Priority enum represents the priority levels of events.
 */
package enums;


public enum Priority {
    MID("mid"),
    HIGH("high");

    private final String priority;
    /**
     * Constructs a Priority enum with the specified priority level.
     *
     * @param priority the priority level.
     * @pre: priority != null
     */
    Priority(String priority) {
        this.priority = priority;
    }

    /**
     * Retrieves the priority level.
     *
     * @return the priority level.
     */
    public String getPriority() {
        return priority;
    }
}