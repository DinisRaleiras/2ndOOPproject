/**
 @author Dinis Raleiras 67819
 @author Filipe Nobre 67850
  * The Answer enum represents the possible responses to an event invitation.
 */
package enums;

public enum Answer {
    ACCEPTED("accept"),
    REJECTED("reject"),
    NO_ANSWER("no_answer");

    private final String answer;

    /**
     * Constructs an Answer enum with the specified response.
     *
     * @param answer the response to an event invitation.
     * @pre: answer !=null
     */
    Answer(String answer){
        this.answer = answer;
    }

    /**
     * Retrieves the response to an event invitation.
     *
     * @return the response to an event invitation.
     */
    public String getAnswer() {
        return answer;
    }

}
