/**
 @author Dinis Raleiras 67819
 @author Filipe Nobre 67850
  * The Role enum represents the roles that users can have in the system.
 */
package enums;


public enum Role {
    GUEST("guest"),
    STAFF("staff"),
    MANAGER("manager");

    private final String role;

    /**
     * Constructs a Role enum with the specified role name.
     *
     * @param role the name of the role.
     * @pre: role!=null
     */
    Role(String role) {
        this.role = role;
    }

    /**
     * Retrieves the name of the role.
     *
     * @return the name of the role.
     */
    public String getRole() {
        return role;
    }
}