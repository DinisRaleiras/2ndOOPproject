/**
@author Dinis Raleiras 67819
@author Filipe Nobre 67850

 */
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.Scanner;
import exceptions.StaffException;
import exceptions.*;
import events.*;
import users.*;
import dataStruck.*;
import enums.*;
import calendar.*;

public class Main {
    private static final String EXIT_MSG = "Bye!";
    private static final String ERROR_MESSAGE = "Unknown command %s. Type help to see available commands.\n";
    private static final String HELP_MSG = "Available commands:\nregister - registers a new account\naccounts - lists all registered accounts\n"
            + "create - creates a new event\n" +
            "events - lists all events of an account\ninvite - invites an user to an event\nresponse - response to an invitation\n" +
            "event - shows detailed information of an event\ntopics - shows all events that cover a list of topics\n" +
            "help - shows the available commands\nexit - terminates the execution of the program";
    private static final String NO_ACCOUNTS_MSG = "No account registered.";
    private static final String ALL_ACCOUNTS_MSG = "All accounts:";
    private static final String ACCOUNTS_MSG = "%s [%s]\n";
    private static final String NEW_ACCOUNT_MSG = "%s was registered.\n";
    private static final String ALREADY_REGISTERED_MSG = "Account %s already exists.\n";
    private static final String UNKNOWN_ROLE_MSG = "Unknown account type.";
    private static final String Event_SCHEDULE_MSG = "%s is scheduled.\n";
    private static final String ACC_NOT_EXISTS_MSG = "Account %s does not exist.\n";
    private static final String UNKNOWN_PRIORITY = "Unknown priority type.";
    private static final String GUEST_CANT_CREATE_MSG = "Guest account %s cannot create events.\n";
    private static final String STAFF_CANT_CREATE_MSG = "Account %s cannot create high priority events.\n";
    private static final String Event_Already_Exists_MSG = "%s already exists in account %s.\n";
    private static final String BUSY_DATE_MSG = "Account %s is busy.\n";
    private static final String NO_EVENTS_MSG = "Account %s has no events.\n";
    private static final String ACCOUNT_MSG = "Account %s events:\n";
    private static final String EVENT_MSG = "%s occurs on %s:\n";
    private static final String EVENTS_MSG = "%s status [invited %d] [accepted %d] [rejected %d] [unanswered %d]\n";
    private static final String EVENT_DONT_EXISTS_MSG = "%s does not exist in account %s.\n";
    private static final String LIST_TOPICS = "%s promoted by %s on %s\n";
    private static final String EVENTS_ON = "Events on topics %s:\n";
    private static final String EVENTS_OFF = "No events on those topics.";
    private static final String ALREADY_INVITED_MSG = "Account %s was already invited.\n";
    private static final String ATTENDING_OTHER_EVENT_MSG = "Account %s already attending another event.\n";
    private static final String EVENT_ACCEPTED = "%s accepted the invitation.\n";
    private static final String EVENT_REJECTED = "%s promoted by %s was rejected.\n";
    private static final String REMOVED_EVENT = "%s promoted by %s was removed.\n";
    private static final String INVITED_MSG = "%s was invited.\n";
    private static final String WRITE_DATE_FORMAT = "dd-MM-yyyy HH'h'";
    private static final String RESPONSE_MSG = "Account %s has replied %s to the invitation.\n";
    private static final String INVALID_ANSWER = "Unknown event response.";
    private static final String NOT_INVITED = "Account %s is not on the invitation list.\n";
    private static final String ALREADY_ANSWER = "Account %s has already responded.\n";

    private static final String REGISTER = "REGISTER";
    private static final String ACCOUNTS = "ACCOUNTS";
    private static final String CREATE = "CREATE";
    private static final String EVENTS = "EVENTS";
    private static final String INVITE = "INVITE";
    private static final String RESPONSE = "RESPONSE";
    private static final String EVENT = "EVENT";
    private static final String TOPICS = "TOPICS";
    private static final String HELP = "HELP";
    private static final String EXIT = "EXIT";

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Calendar calendar = new CalendarClass();

        String comm;

        do {
            comm = getComm(in);

            switch(comm) {
                case REGISTER -> commRegister(calendar, in);
                case ACCOUNTS -> commAccounts(calendar);
                case CREATE -> commCreate(calendar, in);
                case EVENTS -> commEvents(calendar, in);
                case EVENT -> commEvent(calendar, in);
                case INVITE -> commInvite(calendar, in);
                case RESPONSE -> commResponse(calendar, in);
                case TOPICS -> commTopics(calendar, in);
                case HELP -> System.out.println(HELP_MSG);
                case EXIT -> System.out.println(EXIT_MSG);
                default -> System.out.printf(ERROR_MESSAGE, comm);
            }

        }while(!comm.equals(EXIT));
    }
    /**
     * Processes the 'TOPICS' command by searching for events in the calendar that match the specified topics.
     *
     * @param calendar the Calendar object that stores the events.
     * @param in the Scanner object used to read input from the user.*
     * The method reads a line of input from the user to get the topics to search for.
     * It then retrieves an iterator of events that match the topics using the calendar's searchTopics method.
     * If no events match the topics, it prints a message indicating that there are no events.
     * If events are found, it prints a list of those events with their names, promoters, and topics.
     */
    private static void commTopics(Calendar calendar, Scanner in) {
        String topics = in.nextLine().trim();
        Iterator<Event> events = calendar.searchTopics(topics);
        if(!events.hasNext()){
            System.out.println(EVENTS_OFF);
        }else {
            System.out.printf(EVENTS_ON, topics);
            while (events.hasNext()) {
                Event event = events.next();
                System.out.printf(LIST_TOPICS, event.getName(), event.getPromoter().getName(), event.getTopics());
            }
        }
    }
    /**
     * Processes the 'RESPONSE' command by handling a user's response to an event invitation.
     *
     * @param calendar the Calendar object that manages the events and user accounts.
     * @param in the Scanner object used to read input from the user.*
     * The method reads the invitee's name, the user's name, the event name, and the response (answer) from the user.
     * It then attempts to process the response using the calendar's response method.
     * If the response is successfully processed, it prints a confirmation message and lists any rejected events.
     * If any exceptions occur during processing, it catches them and prints appropriate error messages:
     * - NoAccException: If either the invitee or the user does not exist.
     * - InvalidAnswerException: If the provided answer is invalid.
     * - NoEventException: If the specified event does not exist.
     * - NotInvitedException: If the invitee was not invited to the event.
     * - AlreadyAnsweredException: If the invitee has already responded to the event.
     * - SameDateException: If the invitee is already attending another event at the same time.
     */
    private static void commResponse(Calendar calendar, Scanner in) {
        String iName = in.nextLine().trim();
        String name = in.next().trim();
        String eName = in.nextLine().trim();
        String answer = in.nextLine().toLowerCase().trim();
        try {
            Iterator<Event> events = calendar.response(iName, name, eName, answer);
            System.out.printf(RESPONSE_MSG, iName, answer);
            while(events.hasNext()) {
                Event event = events.next();
                System.out.printf(EVENT_REJECTED, event.getName(), event.getPromoter().getName());
            }
        }catch(NoAccException exception) {
            if(!calendar.userExist(iName)) {
                System.out.printf(ACC_NOT_EXISTS_MSG, iName);
            }else {
                System.out.printf(ACC_NOT_EXISTS_MSG, name);
            }
        }catch(InvalidAnswerException exception) {
            System.out.println(INVALID_ANSWER);
        }catch(NoEventException exception) {
            System.out.printf(EVENT_DONT_EXISTS_MSG, eName, name);
        }catch(NotInvitedException exception) {
            System.out.printf(NOT_INVITED, iName);
        }catch(AlreadyAnsweredException exception) {
            System.out.printf(ALREADY_ANSWER, iName);
        }catch(SameDateException exception) {
            System.out.printf(ATTENDING_OTHER_EVENT_MSG, iName);
        }
    }
    /**
     * Processes the 'INVITE' command by inviting a user to an event.
     *
     * @param calendar the Calendar object that manages the events and user accounts.
     * @param in the Scanner object used to read input from the user.*
     * The method reads the invitee's name, the inviter's name, and the event name from the user.
     * If the invitee is staff and the inviter is high-ranking for the event, it uses the calendar's inviteAStaff method.
     * Otherwise, it uses the inviteAManagerOrGuest method.
     * It then prints appropriate messages indicating the result of the invitation.
     * If any exceptions occur during the invitation process, it catches them and prints appropriate error messages:
     * - NoAccException: If either the invitee or the inviter does not exist.
     * - NoEventException: If the specified event does not exist.
     * - AlreadyInvitedException: If the invitee has already been invited to the event.
     * - SameDateException: If the invitee is already attending another event at the same time.
     */
    private static void commInvite(Calendar calendar, Scanner in) {
        String iName = in.nextLine().trim();
        String name = in.next().trim();
        String eName = in.nextLine().trim();

        try {
            if(calendar.isStaff(iName) && calendar.isHigh(name, eName)) {
                Iterator<Event> it = calendar.inviteAStaff(iName, name, eName);
                System.out.printf(EVENT_ACCEPTED, iName);
                while(it.hasNext()) {
                    Event event = it.next();
                    if(calendar.isPromoter(event, iName)) {
                        System.out.printf(REMOVED_EVENT, event.getName(), iName);
                    }else {
                        System.out.printf(EVENT_REJECTED, event.getName(), event.getPromoter().getName());
                    }
                }
            }else {
                calendar.inviteAManagerOrGuest(iName, name, eName);
                System.out.printf(INVITED_MSG, iName);
            }
        }catch(NoAccException exception) {
            if(!calendar.userExist(iName)) {
                System.out.printf(ACC_NOT_EXISTS_MSG, iName);
            }else {
                System.out.printf(ACC_NOT_EXISTS_MSG, name);
            }
        }catch(NoEventException exception) {
            System.out.printf(EVENT_DONT_EXISTS_MSG, eName, name);
        }catch(AlreadyInvitedException exception) {
            System.out.printf(ALREADY_INVITED_MSG, iName);
        }catch(SameDateException exception) {
            System.out.printf(ATTENDING_OTHER_EVENT_MSG, iName);
        }

    }
    /**
     * Processes the 'EVENT' command by displaying detailed information about a specific event.
     *
     * @param calendar the Calendar object that manages the events and user accounts.
     * @param in the Scanner object used to read input from the user.*
     * The method reads the user's name and the event name from the input.
     * It retrieves the event information from the calendar using the user's name and event name.
     * It then prints the event's name and date, followed by a list of invitees and their responses.
     * If any exceptions occur during the retrieval of event information, it catches them and prints appropriate error messages:
     * - NoAccException: If the user does not exist.
     * - NoEventException: If the specified event does not exist.
     */
    private static void commEvent(Calendar calendar, Scanner in) {
        String name = in.next();
        String eName = in.nextLine().trim();
        try{
            Event event = calendar.getEventInfo(name, eName);
            DateTimeFormatter formatterDate = DateTimeFormatter.ofPattern(WRITE_DATE_FORMAT);
            String dateAsString = formatterDate.format(event.getDate());
            System.out.printf(EVENT_MSG, event.getName(), dateAsString);
            Iterator<Pair<User, Answer>> it = event.getInvitees();
            while(it.hasNext()){
                Pair<User, Answer> entry = it.next();
                User user = entry.getFirst();
                Answer answer = entry.getSecond();
                System.out.printf(ACCOUNTS_MSG, user.getName(), answer.getAnswer());
            }
        }catch(NoAccException exception){
            System.out.printf(ACC_NOT_EXISTS_MSG, name);
        }catch(NoEventException exception){
            System.out.printf(EVENT_DONT_EXISTS_MSG, eName, name);
        }

    }
    /**
     * Processes the 'EVENTS' command by listing all events associated with a specific user.
     *
     * @param calendar the Calendar object that manages the events and user accounts.
     * @param in the Scanner object used to read input from the user.*
     * The method reads the user's name from the input.
     * It checks if the user has no events associated with them using the calendar's HaveNoEvents method.
     * If the user has no events, it prints a message indicating this.
     * If the user has events, it retrieves and prints the list of events using the listAccountEvents method.
     * For each event, it prints the event's name, the number of invited, accepted, rejected, and unanswered invitations.
     * If any exceptions occur during the retrieval of the user's events, it catches them and prints appropriate error messages:
     * - NoAccException: If the user does not exist.
     */
    private static void commEvents(Calendar calendar, Scanner in) {
        String name = in.nextLine().trim();
        try{
            if(calendar.HaveNoEvents(name)){
                System.out.printf(NO_EVENTS_MSG, name);
            }else{
                Iterator<Event> it = calendar.listAccountEvents(name);
                System.out.printf(ACCOUNT_MSG, name);
                while(it.hasNext()){
                    Event event = it.next();
                    System.out.printf(EVENTS_MSG, event.getName(), event.getInvited(), event.getNumberOfAnswers(Answer.ACCEPTED), event.getNumberOfAnswers(Answer.REJECTED), event.getNumberOfAnswers(Answer.NO_ANSWER));
                }
            }
        }catch(NoAccException exception){
            System.out.printf(ACC_NOT_EXISTS_MSG, name);
        }
    }
    /**
     * Processes the 'CREATE' command by creating a new event in the calendar.
     *
     * @param calendar the Calendar object that manages the events and user accounts.
     * @param in the Scanner object used to read input from the user.*
     * The method reads the event creator's name, event name, event priority, event date, and event topics from the input.
     * It constructs a LocalDateTime object for the event date.
     * It then attempts to create the event using the calendar's createEvent method.
     * If the event is successfully created, it prints a confirmation message.
     * If any exceptions occur during the event creation process, it catches them and prints appropriate error messages:
     * - NoAccException: If the user does not exist.
     * - UnknownPriorityException: If the provided priority is unknown.
     * - GuestAccountException: If a guest account attempts to create an event.
     * - StaffException: If a staff account attempts to create an event.
     * - EventAlreadyExistsException: If an event with the same name already exists.
     * - SameDateException: If the user already has another event scheduled at the same date and time.
     */
    private static void commCreate(Calendar calendar, Scanner in) {
        String name = in.nextLine().trim();
        String eName = in.nextLine().trim();
        String priority = in.next().toLowerCase().trim();
        int year = in.nextInt();
        int month = in.nextInt();
        int day = in.nextInt();
        int hour = in.nextInt();
        in.nextLine();
        LocalDateTime date = LocalDateTime.of(year, month, day, hour, 0);
        String topics = in.nextLine().trim();
        try{
            calendar.createEvent(name, eName, priority, date, topics);
            System.out.printf(Event_SCHEDULE_MSG, eName);
        }catch(NoAccException exception){
            System.out.printf(ACC_NOT_EXISTS_MSG, name);
        }catch(UnknownPriorityException exception){
            System.out.println(UNKNOWN_PRIORITY);
        }catch(GuestAccountException exception){
            System.out.printf(GUEST_CANT_CREATE_MSG, name);
        }catch(StaffException exception){
            System.out.printf(STAFF_CANT_CREATE_MSG, name);
        }catch(EventAlreadyExistsException exception){
            System.out.printf(Event_Already_Exists_MSG, eName, name);
        }catch(SameDateException exception){
            System.out.printf(BUSY_DATE_MSG, name);
        }
    }
    /**
     * Processes the 'ACCOUNTS' command by listing all registered user accounts.
     *
     * @param calendar the Calendar object that manages the events and user accounts.*
     * The method checks if there are no registered accounts using the calendar's noAccountsRegistered method.
     * If no accounts are registered, it prints a message indicating this.
     * If there are accounts registered, it retrieves and prints the list of all user accounts using the getAccounts method.
     * For each account, it prints the user's name and role.
     */
    private static void commAccounts(Calendar calendar) {
        if(calendar.noAccountsRegistered()){
            System.out.println(NO_ACCOUNTS_MSG);
        }else{
            System.out.println(ALL_ACCOUNTS_MSG);
            Iterator<User> it = calendar.getAccounts();
            while(it.hasNext()){
                User user = it.next();
                System.out.printf(ACCOUNTS_MSG, user.getName(), user.getRole());
            }
        }
    }
    /**
     * Processes the 'REGISTER' command by creating a new user account.
     *
     * @param calendar the Calendar object that manages the events and user accounts.
     * @param in the Scanner object used to read input from the user.*
     * The method reads the user's name and role from the input.
     * It then attempts to create a new account using the calendar's createAccount method.
     * If the account is successfully created, it prints a confirmation message.
     * If any exceptions occur during the account creation process, it catches them and prints appropriate error messages:
     * - AlreadyRegisteredException: If an account with the same name already exists.
     * - RoleException: If the provided role is unknown or invalid.
     */
    private static void commRegister(Calendar calendar, Scanner in) {
        String name = in.next();
        String role = in.nextLine().trim().toLowerCase();
        try{
            calendar.createAccount(name, role);
            System.out.printf(NEW_ACCOUNT_MSG, name);
        }catch(AlreadyRegisteredException exception){
            System.out.printf(ALREADY_REGISTERED_MSG, name);
        }catch(RoleException exception){
            System.out.println(UNKNOWN_ROLE_MSG);
        }
    }
    /**
     * Reads a command from the user input and converts it to uppercase.
     *
     * @param in the Scanner object used to read input from the user.
     * @return the command string in uppercase.
     *
     * The method reads a string from the user input, converts it to uppercase, and returns it.
     */
    private static String getComm(Scanner in) {
        String input;
        input = in.next().toUpperCase();
        return input;
    }
}
