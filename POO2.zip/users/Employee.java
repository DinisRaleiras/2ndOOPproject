/**
@author Dinis Raleiras 67819
@author Filipe Nobre 67850
This interface extends the User interface and represents an employee in the system. It declares a method
createMidPriorityEvent for creating events with mid priority. This method allows an employee to create an event with the
specified name, date, and topics. It may throw exceptions such as EventAlreadyExistsException if an event with the same
name already exists, and SameDateException if another event is scheduled on the same date. This interface defines the
behavior expected from employees regarding event creation.

 */
package users;

import java.time.LocalDateTime;
import exceptions.*;
import events.*;

public interface Employee extends User{
    /**
     * Creates an event with mid priority.
     *
     * @param eName the name of the event to be created.
     * @param date the date of the event.
     * @param topics the topics to be covered in the event.
     * @return the created mid priority event.
     * @throws EventAlreadyExistsException if an event with the same name already exists.
     * @throws SameDateException if another event is scheduled on the same date.
     * @pre: eName!=null && date!=null && topics!=null
     */
    Event createMidPriorityEvent(String eName, LocalDateTime date,  String topics) throws EventAlreadyExistsException,
            SameDateException;
}
