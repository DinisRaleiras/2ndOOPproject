/**
@author Dinis Raleiras 67819
@author Filipe Nobre 67850

 */
package users;

import java.time.LocalDateTime;
import java.util.ArrayList;
import exceptions.*;
import events.*;
import enums.*;
public class StaffClass extends AbstractUserClass implements Staff{

    public StaffClass(String name) {
        super(name);
    }

    @Override
    public String getRole() {
        return Role.STAFF.getRole();
    }

    @Override
    public Event createMidPriorityEvent(String eName, LocalDateTime date, String topics)
            throws EventAlreadyExistsException, SameDateException {
        if(super.haveEvent(eName)) {
            throw new EventAlreadyExistsException();
        }else if(super.eventInSameDate(date)) {
            throw new SameDateException();
        }else{
            Event event = new EventClass(this, eName, Priority.MID, date, topics);
            super.rejectEventsInDate(event.getDate());
            super.accept(event);
            super.addEvent(event);
            return event;
        }
    }

    @Override
    public ArrayList<Event> rejectAllEventsInDate(LocalDateTime date) {
        ArrayList<Event> rejectedEvents = new ArrayList<>();
        for(int i = 0; i < invitedEvents.size(); i++) {
            Event event = invitedEvents.get(i);
            if(event.getDate().isEqual(date) && !event.getState(this).equals(Answer.REJECTED)) {
                rejectedEvents.add(event);
                if(acceptedEvents.contains(event)) {
                    super.removeEvent(event);
                }
                event.reject(this);
            }
        }
        return rejectedEvents;
    }

}
