/**
 @author Dinis Raleiras 67819
 @author Filipe Nobre 67850
 */
package users;
import exceptions.*;
import events.*;
import enums.*;
import java.time.LocalDateTime;

public class ManagerClass extends AbstractUserClass implements Manager{

    public ManagerClass(String name) {
        super(name);
    }

    @Override
    public String getRole() {
        return Role.MANAGER.getRole();
    }

    @Override
    public Event createMidPriorityEvent(String eName, LocalDateTime date, String topics)
            throws EventAlreadyExistsException, SameDateException {
        if(super.haveEvent(eName)) {
            throw new EventAlreadyExistsException();
        }else if(super.eventInSameDate(date)) {
            throw new SameDateException();
        }else{
            Event event = new EventClass(this, eName, Priority.MID, date, topics);
            super.rejectEventsInDate(event.getDate());
            super.accept(event);
            super.addEvent(event);
            return event;
        }
    }

    @Override
    public Event createHighPriorityEvent(String eName, LocalDateTime date, String topics)
            throws EventAlreadyExistsException, SameDateException {
        if(super.haveEvent(eName)) {
            throw new EventAlreadyExistsException();
        }else if(super.eventInSameDate(date)) {
            throw new SameDateException();
        }else{
            Event event = new EventClass(this, eName, Priority.HIGH, date, topics);
            super.rejectEventsInDate(event.getDate());
            super.accept(event);
            super.addEvent(event);
            return event;
        }
    }


}
