/**
@author Dinis Raleiras 67819
@author Filipe Nobre 67850

 */
package users;
import events.*;
import java.time.LocalDateTime;
import java.util.ArrayList;

public interface Staff extends Employee{
    /**
     * Rejects all events scheduled on the specified date for the staff member.
     *
     * @param date the date of the events to be rejected.
     * @return an ArrayList containing all the events rejected by the staff member on the specified date.
     * @pre: date != null
     */
    ArrayList<Event> rejectAllEventsInDate(LocalDateTime date);
}
