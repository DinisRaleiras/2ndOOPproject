/**
 @author Dinis Raleiras 67819
 @author Filipe Nobre 67850

 This class represents a user in a system that manages events and invitations. Users can be invited to events,
 accept or reject invitations, and manage their list of accepted and invited events. The class provides methods for accepting,
 rejecting, and removing event invitations, as well as checking for event conflicts and retrieving event information. Additionally,
 it includes methods for managing the user's list of accepted and invited events. Overall, the class facilitates user interactions
 with events and invitations within the system.

 */
package users;
import exceptions.*;
import java.time.LocalDateTime;
import java.util.Iterator;
import events.Event;
public interface User extends Comparable<User>{
    /**
     * Compares this user to another user for order based on their names.
     *
     * @param other the other User object to be compared.
     * @return a negative integer, zero, or a positive integer as this user's name
     *         is less than, equal to, or greater than the specified user's name.
     * @pre: other!=null
     */
    int compareTo(User other);
    /**
     * Indicates whether some other object is "equal to" this one.
     *
     * @param obj the reference object with which to compare.
     * @return true if this object is the same as the obj argument; false otherwise.
     * Returns true if the names are equal, and false otherwise.
     * @pre: obj!=null
     */
    boolean equals(Object obj);
    /**
     * Returns the name of the user.
     *
     * @return the name of the user.
     */
    String getName();
    /**
     * Retrieves the role of the user.
     *
     * @return the role of the user.
     */
    String getRole();
    /**
     * Returns an iterator over the events to which the user is invited.
     *
     * @return an iterator over the events to which the user is invited.
     */
    Iterator<Event> getAccountEvents();
    /**
     * Adds an event to the list of accepted events for the user.
     *
     * @param event the event to be added.
     * @pre: event!=null
     */
    void addEvent(Event event);
    /**
     * Removes an event from the list of accepted events for the user.
     *
     * @param event the event to be removed.
     * @pre: event!=null  && !NoEventException()
     */
    void removeEvent(Event event);
    /**
     * Checks if the user has an event with the specified name.
     *
     * @param name the name of the event to check for.
     * @return true if the user has an event with the specified name, false otherwise.
     * @pre: event!=null
     */
    boolean haveEvent(String name);
    /**
     * Checks if the user has an event scheduled on the specified date.
     *
     * @param date the date to check for events.
     * @return true if the user has an event scheduled on the specified date, false otherwise.
     * @pre: event!=null
     */
    boolean eventInSameDate(LocalDateTime date);
    /**
     * Checks if the user has no events.
     *
     * @return true if the user has no events, false otherwise.
     * @pre: date!=null
     */
    boolean HaveNoEvents();
    /**
     * Invites a user to an event.
     *
     * @param invited the user to be invited.
     * @param event the event to which the user is invited.
     * @pre: invited!=null && event !=null && !NoEventException() && !NoAccException()
     */
    void invite(User invited, Event event);
    /**
     * Retrieves the event scheduled on the specified date for the user.
     *
     * @param date the date of the event to retrieve.
     * @return the event scheduled on the specified date for the user, or null if no such event exists.
     * @pre: invited!=null && event !=null && !NoEventException() && !NoAccException()
     */
    Event getEvent(LocalDateTime date);
    /**
     * Accepts an invitation to an event.
     *
     * @param event the event to be accepted.
     * @pre: date!=null
     */
    void accept(Event event);
    /**
     * Checks if the user is invited to the specified event.
     *
     * @param event the event to check for invitation.
     * @return true if the user is invited to the event, false otherwise.
     * @pre: event !=null && !NoEventException()
     */
    boolean haveEvent(Event event);
    /**
     * Adds an event to the list of invited events for the user.
     * Also adds the user to the list of invited attendees for the event.
     *
     * @param event the event to be added.
     * @pre: event!=null
     */
    void addInvitedEvent(Event event);
    /**
     * Rejects an invitation to an event.
     *
     * @param event the event to be rejected.
     * @pre: event !=null  && !NoEventException()
     */
    void rejectEvent(Event event);
    /**
     * Rejects all events scheduled on the specified date for the user.
     *
     * @param date the date of the events to be rejected.
     * @pre: date!=null
     */
    void rejectEventsInDate(LocalDateTime date);
/**
 * Accepts an invitation to an event and rejects other events with the same date.
 *
 * @param event the event to be accepted.
 * @return an iterator over the events that were rejected due to having the same date as the accepted event.
 * @throws SameDateException if another invited event has the same date as the accepted event.
 * @pre: event !=null !NoEventException()
 */
    Iterator<Event> acceptInvite(Event event) throws SameDateException;
    /**
     * Removes an event invitation from the list of invited events for the user.
     *
     * @param event the event invitation to be removed.
     * @pre: event!=null && !NoEventException()
     */
    void removeInvite(Event event);
}

