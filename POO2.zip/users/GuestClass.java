/**
 @author Dinis Raleiras 67819
 @author Filipe Nobre 67850
 */
package users;
import enums.*;


public class GuestClass extends AbstractUserClass {

    public GuestClass(String name) {
        super(name);
    }

    @Override
    public String getRole() {
        return Role.GUEST.getRole();
    }
}
