package users;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import exceptions.*;
import events.*;

public abstract class AbstractUserClass implements User{
    private final String name;
    protected List<Event> acceptedEvents;
    protected List<Event> invitedEvents;

    protected AbstractUserClass(String name) {
        this.name = name;
        acceptedEvents = new ArrayList<>();
        invitedEvents = new ArrayList<>();
    }

    public int compareTo(User other) {
        return this.name.compareTo(other.getName());
    }

    public Iterator<Event> getAccountEvents(){
        return invitedEvents.iterator();
    }

    public String getName() {
        return name;
    }

    public void addEvent(Event event) {
        if(!acceptedEvents.contains(event))
            acceptedEvents.add(event);
    }

    public void removeEvent(Event event) {
        acceptedEvents.remove(event);
    }

    public boolean haveEvent(String name) {
        return acceptedEvents.contains(new EventClass(this, name, null, null, null));
    }

    public boolean eventInSameDate(LocalDateTime date) {
        boolean found = false;
        int i = 0;
        while(i < acceptedEvents.size() && !found) {
            Event event = acceptedEvents.get(i);
            if(event.getDate().isEqual(date)) {
                found = true;
            }
            i++;
        }
        return found;
    }

    public boolean equals(Object obj) {
        if(obj instanceof User) {
            User other = (User)obj;
            return this.name.equals(other.getName());
        }
        return false;
    }

    public boolean HaveNoEvents() {
        return invitedEvents.isEmpty();
    }

    public void invite(User invited, Event event) {
        invited.addInvitedEvent(event);
        event.addInvited(invited);
    }

    public Event getEvent(LocalDateTime date) {
        Event event = null;
        int i = 0;
        while(i < acceptedEvents.size() && event == null) {
            Event actual = acceptedEvents.get(i);
            if(actual.getDate().isEqual(date)) {
                event = actual;
            }
        }
        return event;
    }

    public void accept(Event event) {
        addEvent(event);
        addInvitedEvent(event);
        event.accept(this);
    }

    public boolean haveEvent(Event event) {
        return invitedEvents.contains(event);
    }

    public void addInvitedEvent(Event event) {
        invitedEvents.add(event);
        event.addInvited(this);
    }

    public void removeInvite(Event event) {
        invitedEvents.remove(event);
    }

    public void rejectEvent(Event event) {
        event.reject(this);
    }

    public void rejectEventsInDate(LocalDateTime date) {
        for(int i = 0; i < invitedEvents.size(); i++) {
            Event event = invitedEvents.get(i);
            if(event.getDate().isEqual(date)) {
                if(acceptedEvents.contains(event)) {
                    removeEvent(event);
                }
                event.reject(this);
            }
        }
    }

    public Iterator<Event> acceptInvite(Event event) throws SameDateException{
        if(eventInSameDate(event.getDate())) {
            throw new SameDateException();
        }
        List<Event> events = new ArrayList<>();
        for(int i = 0; i < invitedEvents.size(); i++) {
            Event other = invitedEvents.get(i);
            if(!other.equals(event) && other.getDate().isEqual(event.getDate())) {
                events.add(other);
                rejectEvent(other);
            }
        }
        addEvent(event);
        event.accept(this);
        return events.iterator();
    }
}
