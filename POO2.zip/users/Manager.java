/**
 @author Dinis Raleiras 67819
 @author Filipe Nobre 67850

 This interface Manager extends the Employee interface, which itself extends the User interface, representing a
 manager in the system. It adds a method createHighPriorityEvent for creating events with high priority. This method allows
 a manager to create an event with the specified name, date, and topics. Similar to the createMidPriorityEvent method in the
 Employee interface, it may throw exceptions such as EventAlreadyExistsException if an event with the same name already exists,
 and SameDateException if another event is scheduled on the same date. This interface further defines the behavior expected from
 managers regarding event creation.
 */
package users;
import exceptions.*;
import events.*;
import java.time.LocalDateTime;

public interface Manager extends Employee{
    /**
     * Creates an event with high priority.
     *
     * @param eName the name of the event to be created.
     * @param date the date of the event.
     * @param topics the topics to be covered in the event.
     * @return the created high priority event.
     * @throws EventAlreadyExistsException if an event with the same name already exists.
     * @throws SameDateException if another event is scheduled on the same date.
     * @pre: eName != null && date != null && topics != null
     */
    Event createHighPriorityEvent(String eName, LocalDateTime date, String topics) throws EventAlreadyExistsException,
            SameDateException;
}
