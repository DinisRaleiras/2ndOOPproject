/**
 @author Dinis Raleiras 67819
 @author Filipe Nobre 67850

 */
package events;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import users.*;
import dataStruck.*;
import enums.*;


public class EventClass implements Event{
    private final User promoter;
    private final String name;
    private final Priority priority;
    private final LocalDateTime date;
    private final String[] topics;
    private Map<User, Answer> invitees;
    private List<User> usersInvitees;

    public EventClass(User promoter, String name, Priority priority, LocalDateTime date, String topics) {
        this.promoter = promoter;
        this.name = name;
        this.priority = priority;
        this.date = date;
        if(topics != null) {
            this.topics = topics.split(" ");
        }else {
            this.topics = null;
        }
        invitees = new HashMap<>();
        usersInvitees = new ArrayList<>();
        usersInvitees.add(promoter);
    }

    public boolean equals(Object obj) {
        if(obj instanceof Event) {
            Event other = (Event)obj;
            return this.promoter.equals(other.getPromoter()) && this.name.equals(other.getName());
        }
        return false;
    }

    @Override
    public User getPromoter() {
        return promoter;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public LocalDateTime getDate() {
        return date;
    }

    @Override
    public int getInvited() {
        return invitees.size();
    }


    @Override
    public Iterator<Pair<User, Answer>> getInvitees() {
        List<Pair<User, Answer>> list = new ArrayList<>();
        for(int i = 0; i < usersInvitees.size(); i++) {
            User user = usersInvitees.get(i);
            list.add(new Pair<>(user, invitees.get(user)));
        }
        return list.iterator();
    }






    @Override
    public Priority getPriority() {
        return priority;
    }

    @Override
    public boolean isInvited(User user) {
        return invitees.containsKey(user);
    }

    @Override
    public void addInvited(User invited) {
        invitees.put(invited, Answer.NO_ANSWER)	;
        if(!usersInvitees.contains(invited)) {
            usersInvitees.add(invited);
        }
    }

    @Override
    public void accept(User user) {
        if(!user.equals(promoter)) {
            invitees.put(user, Answer.ACCEPTED);
            if(!usersInvitees.contains(user)) {
                usersInvitees.add(user);
            }
        }else {
            invitees.replace(user, Answer.ACCEPTED);
        }
    }

    @Override
    public void reject(User user) {
        invitees.replace(user, Answer.REJECTED);
    }

    @Override
    public String getTopics() {
        String tp = "";
        for(int i = 0; i < topics.length; i++) {
            tp += topics[i] + " ";
        }
        return tp.trim();
    }

    @Override
    public int getSameTopics(String[] topicsArray) {
        int n = 0;
        for(int i = 0; i < topicsArray.length; i++) {
            boolean found = false;
            int j = 0;
            while(j < topics.length && !found) {
                if(topicsArray[i].equals(topics[j])) {
                    found = true;
                    n++;
                }
                j++;
            }
        }
        return n;
    }

    @Override
    public boolean alreadyAnswered(User invited) {
        return !invitees.get(invited).equals(Answer.NO_ANSWER);
    }

    @Override
    public Answer getState(User user) {
        return invitees.get(user);
    }

    @Override
    public int getNumberOfAnswers(Answer answer) {
        int number = 0;
        Iterator<User> it = usersInvitees.iterator();
        while(it.hasNext()) {
            User user = it.next();
            Answer response = invitees.get(user);
            if(response.equals(answer)) {
                number++;
            }
        }
        return number;
    }
}
