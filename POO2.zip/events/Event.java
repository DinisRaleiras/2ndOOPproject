/**
 @author Dinis Raleiras 67819
 @author Filipe Nobre 67850
 This Event interface represents an event in the system. It defines methods for retrieving information about the event
 such as its name, date, priority, number of invited attendees, and their acceptance status. Additionally, it provides
 methods for managing the event's invitees, including accepting or rejecting invitations, and checking if a user is invited
 to the event. The interface also includes methods for retrieving event topics, determining the number of common topics with
 a given array, and checking whether a user has already answered the invitation. Overall, this interface facilitates
 interactions with events within the system.
 */
package events;

import java.time.LocalDateTime;
import java.util.Iterator;
import users.*;
import dataStruck.*;
import enums.*;



public interface Event {
    /**
     * Indicates whether some other object is "equal to" this one.
     *
     * @param obj the reference object with which to compare.
     * @return true if this object is the same as the obj argument; false otherwise.
     * @pre: obj != null
     */
    boolean equals(Object obj);
    /**
     * Retrieves the user who is the promoter of the event.
     *
     * @return the user who is the promoter of the event.
     */
    User getPromoter();
    /**
     * Retrieves the name of the event.
     *
     * @return the name of the event.
     */
    String getName();
    /**
     * Retrieves the date and time of the event.
     *
     * @return the date and time of the event.
     */
    LocalDateTime getDate();
    /**
     * Retrieves the number of invited attendees for the event.
     *
     * @return the number of invited attendees for the event.
     */
    int getInvited();
    /**
     * Retrieves an iterator over the invitees of the event along with their response status.
     *
     * @return an iterator over the invitees of the event along with their response status.
     */
    Iterator<Pair<User, Answer>> getInvitees();
    /**
     * Retrieves the priority of the event.
     *
     * @return the priority of the event.
     */
    Priority getPriority();
    /**
     * Checks if the specified user is invited to the event.
     *
     * @param user the user to check for invitation.
     * @return true if the user is invited to the event, false otherwise.
     * @pre: user!=null
     */
    boolean isInvited(User user);
    /**
     * Adds the specified user to the list of invitees for the event with an initial response status of "NO_ANSWER".
     * If the user is not already included in the list of invitees, they are added.
     *
     * @param invited the user to be added as an invitee.
     * @pre: invited!=null
     */
    void addInvited(User invited);
    /**
     * Accepts the invitation for the specified user to attend the event.
     * If the user is not the promoter, their response status is updated to "ACCEPTED".
     * If the user is the promoter, their response status remains unchanged.
     *
     * @param user the user whose invitation to the event is being accepted.
     * @pre: user!=null
     */
    void accept(User user);
    /**
     * Rejects the invitation for the specified user to attend the event by updating their response status to "REJECTED".
     *
     * @param user the user whose invitation to the event is being rejected.
     * @pre: user !=null
     */
    void reject(User user);
    /**
     * Retrieves the topics covered in the event as a single string.
     *
     * @return the topics covered in the event as a single string.
     */
    String getTopics();
    /**
     * Determines the number of topics covered in the event that match those provided in the specified array.
     *
     * @param topicsArray an array containing topics to compare against the event's topics.
     * @return the number of topics covered in the event that match those provided in the specified array.
     * @pre: topicsArray !=null
     */
    int getSameTopics(String[] topicsArray);
    /**
     * Checks if the specified invited user has already responded to the event invitation.
     *
     * @param invited the invited user to check for a response.
     * @return true if the invited user has already responded to the event invitation, false otherwise.
     * @pre: invited != null
     */
    boolean alreadyAnswered(User invited);
    /**
     * Retrieves the response status of the specified user to the event invitation.
     *
     * @param user the user whose response status to retrieve.
     * @return the response status of the specified user to the event invitation.
     * @pre: user !=null
     */
    Answer getState(User user);
    /**
     * Retrieves the number of responses with a certain answer.
     *
     * @param answer the answer whose response status to retrieve.
     * @return the number of responses of the specified answer of the event.
     * @pre: answer != null !InvalidAnswerException()
     */
    int getNumberOfAnswers(Answer answer);


}
