/**
 @author Dinis Raleiras 67819
 @author Filipe Nobre 67850

 */
package exceptions;


@SuppressWarnings("serial")
public class AlreadyInvitedException extends Exception {
    public AlreadyInvitedException() {
        super();
    }
}
