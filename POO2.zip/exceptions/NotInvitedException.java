/**
 @author Dinis Raleiras 67819
 @author Filipe Nobre 67850

 */
package exceptions;


@SuppressWarnings("serial")
public class NotInvitedException extends Exception {
    public NotInvitedException() {
        super();
    }
}
